### BLUETOOTH
| Index | Entry Point & APIs | Screen shot | Resource id | Label |
| ------------- | ------------- | ------------- |-------------|-------------|
| 1 | <com.lavadip.skeye.SkEye: boolean onOptionsItemSelected(android.view.MenuItem)>; java.util.Set getBondedDevices | ![](D:\COSMOS\output\py\Play_win8\Education\com.lavadip.skeye\com.lavadip.skeye.SkEye.png) |  | F |
