### BLUETOOTH
| Index | Entry Point & APIs | Screen shot | Resource id | Label |
| ------------- | ------------- | ------------- |-------------|-------------|
| 51 | <com.jjkeller.kmb.RptGridImage: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.RptGridImage.png) |  | |
| 52 | <com.jjkeller.kmb.RptLogDetail: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.RptLogDetail.png) |  | |
| 53 | <com.jjkeller.kmb.RptLogDetail: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.RptLogDetail.png) |  | |
| 54 | <com.jjkeller.kmb.SplashScreen: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.SplashScreen.png) |  | |
| 55 | <com.jjkeller.kmb.SplashScreen: void onCompletion(android.media.MediaPlayer)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.SplashScreen.png) |  | |
| 56 | <com.jjkeller.kmb.SubmitLogsViewOnly: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.SubmitLogsViewOnly.png) |  | |
| 57 | <com.jjkeller.kmb.SubmitLogsViewOnly: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.SubmitLogsViewOnly.png) |  | |
| 58 | <com.jjkeller.kmb.SystemMenu: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.SystemMenu.png) |  | |
| 59 | <com.jjkeller.kmb.TripInfo: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.TripInfo.png) |  | |
| 60 | <com.jjkeller.kmb.VehicleInspectionCreate: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.VehicleInspectionCreate.png) |  | |
| 61 | <com.jjkeller.kmb.ViewClocks: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewClocks.png) |  | |
| 62 | <com.jjkeller.kmb.ViewClocks: boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewClocks.png) |  | |
| 63 | <com.jjkeller.kmb.ViewClocks: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewClocks.png) |  | |
| 64 | <com.jjkeller.kmb.ViewHours: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewHours.png) |  | |
| 65 | <com.jjkeller.kmb.ViewHours: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewHours.png) |  | |
| 66 | <com.jjkeller.kmb.ViewHours: boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewHours.png) |  | |
| 67 | <com.jjkeller.kmb.ViewLog: boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewLog.png) |  | |
| 68 | <com.jjkeller.kmb.ViewLog: boolean onKeyDown(int,android.view.KeyEvent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.jjkeller.kmb\com.jjkeller.kmb.ViewLog.png) |  | |
| 69 | <com.manheim.mobile.activities.LoginActivity: void onPause()>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.LoginActivity.png) |  | D |
| 70 | <com.manheim.mobile.activities.MainActivity: boolean onCreateOptionsMenu(android.view.Menu)>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.MainActivity.png) |  | D |
| 71 | <com.manheim.mobile.activities.MainActivity: void onPause()>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.MainActivity.png) |  | D |
| 72 | <com.manheim.mobile.activities.ScanHelpActivity: void onPause()>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.ScanHelpActivity.png) |  | D |
| 73 | <com.manheim.mobile.activities.SimulcastActivity: boolean onCreateOptionsMenu(android.view.Menu)>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.SimulcastActivity.png) |  | D |
| 74 | <com.manheim.mobile.activities.SimulcastActivity: void onPause()>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.activities.SimulcastActivity.png) |  | D |
| 75 | <com.manheim.mobile.ManualVinEntry.ManualEntryActivity: void onPause()>; boolean isEnabled | ![](D:\COSMOS\output\py\Play_win8\Business\com.manheim.mobile\com.manheim.mobile.ManualVinEntry.ManualEntryActivity.png) |  | D |
| 76 | <com.ontheclock.otc.otc.Forms.Dashboard: void onCreate(android.os.Bundle)>; java.lang.String getName | ![](D:\COSMOS\output\py\Play_win8\Business\com.ontheclock.otc.otc\com.ontheclock.otc.otc.Forms.Dashboard.png) |  | |
| 77 | <com.ontheclock.otc.otc.NewAccount: void cmdCreateAccount_Click(android.view.View)>; java.lang.String getName | ![](D:\COSMOS\output\py\Play_win8\Business\com.ontheclock.otc.otc\com.ontheclock.otc.otc.NewAccount.png) |  | F |
| 78 | <com.ProfitBandit.main.BaseActivity: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.BaseActivity.png) |  | D |
| 79 | <com.ProfitBandit.main.BaseActivity: void onBackPressed()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.BaseActivity.png) |  | D |
| 80 | <com.ProfitBandit.main.BaseActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.BaseActivity.png) |  | D |
| 81 | <com.ProfitBandit.main.BuyListActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.BuyListActivity.png) |  | D |
| 82 | <com.ProfitBandit.main.BuyListActivity: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.BuyListActivity.png) |  | D |
| 83 | <com.ProfitBandit.main.ConfirmEmailActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ConfirmEmailActivity.png) |  | F |
| 84 | <com.ProfitBandit.main.HistoryActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.HistoryActivity.png) |  | D |
| 85 | <com.ProfitBandit.main.HistoryActivity: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.HistoryActivity.png) |  | D |
| 86 | <com.ProfitBandit.main.LoginActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.LoginActivity.png) |  | F |
| 87 | <com.ProfitBandit.main.ManageAccountActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ManageAccountActivity.png) |  | D |
| 88 | <com.ProfitBandit.main.MWSSetupActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.MWSSetupActivity.png) |  | F |
| 89 | <com.ProfitBandit.main.PluginsActivity: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.PluginsActivity.png) |  | |
| 90 | <com.ProfitBandit.main.PluginsActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.PluginsActivity.png) |  | |
| 91 | <com.ProfitBandit.main.ProfitBandit: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ProfitBandit.png) |  | D |
| 92 | <com.ProfitBandit.main.ProfitBandit: void onNewIntent(android.content.Intent)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ProfitBandit.png) |  | D |
| 93 | <com.ProfitBandit.main.ProfitBandit: void onActivityResult(int,int,android.content.Intent)>; boolean startDiscovery | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ProfitBandit.png) |  | D |
| 94 | <com.ProfitBandit.main.ProfitBandit: void onResume()>; boolean startDiscovery | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.ProfitBandit.png) |  | D |
| 95 | <com.ProfitBandit.main.SignUpActivity: void onResume()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.SignUpActivity.png) |  | F |
| 96 | <com.ProfitBandit.main.SplashScreen: void onDestroy()>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.ProfitBandit.main.SplashScreen.png) |  | |
| 97 | <com.uservoice.uservoicesdk.activity.ContactActivity: void onCreate(android.os.Bundle)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.uservoice.uservoicesdk.activity.ContactActivity.png) |  | F |
| 98 | <com.uservoice.uservoicesdk.activity.PortalActivity: void onCreate(android.os.Bundle)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.uservoice.uservoicesdk.activity.PortalActivity.png) |  | F |
| 99 | <com.uservoice.uservoicesdk.activity.PortalActivity: boolean onOptionsItemSelected(android.view.MenuItem)>; void connect | ![](D:\COSMOS\output\py\Play_win8\Business\com.ProfitBandit\com.uservoice.uservoicesdk.activity.PortalActivity.png) |  | F |
